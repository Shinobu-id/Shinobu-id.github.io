clear
neofetch
bash x