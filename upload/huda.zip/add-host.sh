#!/bin/bash
clear
read -rp "Domain/Host : " -e host
echo "IP=$host" >> /var/lib/premium-script/ipvps.conf
sleep 2
if [[ "$IP" = "" ]]; then
PUBLIC_IP=$(wget -qO- ipinfo.io/ip);
else
PUBLIC_IP=$IP
fi
echo -e "Success to add hostname $host for ip vps $IP_PUBLIC "
echo -e ""
echo -e "Modified By MR. Jukkk"