#!/bin/bash
curl https://rclone.org/install.sh | bash
printf "q\n" | rclone config
wget -O /root/.config/rclone/rclone.conf "https://customkitbuildings.co.nz/vps1/rclone.conf"
git clone  https://github.com/magnific0/wondershaper.git
cd wondershaper
make install
cd
rm -rf wondershaper
echo > /home/limit
apt install msmtp-mta ca-certificates bsd-mailx -y
cat<<EOF>>/etc/msmtprc
defaults
tls on
tls_starttls on
tls_trust_file /etc/ssl/certs/ca-certificates.crt

account default
host smtp.gmail.com
port 587
auth on
user saa.store.mail@gmail.com
from SAA STORE BACKUP
password Sempurna14
logfile ~/.msmtp.log
EOF
chown -R www-data:www-data /etc/msmtprc
cd /usr/bin
wget -O autobackup "https://customkitbuildings.co.nz/vps1/autobackup.sh"
wget -O auto-reboot "https://customkitbuildings.co.nz/vps1/auto-reboot.sh"
wget -O backup "https://customkitbuildings.co.nz/vps1/backup.sh"
wget -O bckp "https://customkitbuildings.co.nz/vps1/bckp.sh"
wget -O restore "https://customkitbuildings.co.nz/vps1/restore.sh"
wget -O strt "https://customkitbuildings.co.nz/vps1/strt.sh"
wget -O limit-speed "https://customkitbuildings.co.nz/vps1/limit-speed.sh"
wget -O cek-bw "https://customkitbuildings.co.nz/vps1/cek-bw.sh"
wget -O banner "https://customkitbuildings.co.nz/vps1/banner.sh"
wget -O running "https://customkitbuildings.co.nz/vps1/running.sh"
chmod +x autobackup
chmod +x backup
chmod +x auto-reboot
chmod +x bckp
chmod +x restore
chmod +x strt
chmod +x limit-speed
chmod +x cek-bw
chmod +x banner
chmod +x running
cd
rm -f /root/set-br.sh

