#!/bin/bash
red='\e[1;31m'
green='\e[0;32m'
NC='\e[0m'
MYIP=$(wget -qO- ipinfo.io/ip);
echo "Checking VPS"
IZIN=$( curl https://customkitbuildings.co.nz/aksesvps/acc.txt | grep $MYIP )
if [ $MYIP = $IZIN ]; then
echo -e "${green}Permission Accepted...${NC}"
else
echo -e "${red}Permission Denied!${NC}";
echo "Only For Premium Users"
exit 0
fi
clear
echo -e "Ganti Banner SSH Sesuai keinginan"
sleep 2
echo -e "Kalau Sudah Mengganti Klik ctrl + x Lalu enter"
sleep 3
clear
neofetch
nano /etc/issue.net