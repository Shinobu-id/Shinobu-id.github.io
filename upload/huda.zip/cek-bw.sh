#!/bin/bash

clear
echo -e "Checking Bandwidth VPS"
sleep 2
vnstat
echo -e ""
