<?php
$ip_log = false; // Set to true to enable ip logging
$adminMail = "contact@admin.de" // Mail where input of contact form is send to.
?>