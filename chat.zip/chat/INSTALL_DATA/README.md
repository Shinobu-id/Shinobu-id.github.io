
  
     1. DUMP "EINSPIELEN" (Erstellt Chat Datenbank auf dem Mysql DB-Server.
     2. DBCONF.PHP BEARBEITEN
     3. CONF.PHP BEARBEITEN

     1. Import chat.sql (creates chat db) into your mysql DB-Server.
     2. Edit dbconf.php
     3. Edit conf.php